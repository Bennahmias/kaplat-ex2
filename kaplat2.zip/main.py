import http.client
import json
import urllib.parse

host = 'localhost'
port = 6767
url1 = f'/test_get_method?id=207192295&year=1999'
headers = {'Content-Type': 'application/json'}
conn = http.client.HTTPConnection(host, port)

#  first request of get
conn.request("GET", url1)
response1 = conn.getresponse()
print("Response:", response1.reason)
print("Status:", response1.status)
first_response = response1.read().decode()
print("First Response:", first_response)


#  second request of post
url2 = '/test_post_method'
data2 = {
    "id": 207192295,
    "year": 1999,
    "requestId": first_response
}
json_data2 = json.dumps(data2)
conn.request("POST", url2, body=json_data2, headers=headers)
response2 = conn.getresponse()
print("Response:", response2.reason)
print("Status:", response2.status)
second_response = json.loads(response2.read().decode())["message"]
print("Second Response:", second_response)


#  third request of put
###url3 = f'/test_put_method?id={second_response}'
endpointPut = "/test_put_method"
query_params = urllib.parse.urlencode({"id": second_response})
url3 = f"{endpointPut}?{query_params}"
data3 = {
    #  (207192295 - 123503) % 92
    "id": 68,
    #  (1999 + 123) % 45
    "year": 7
}
json_data3 = json.dumps(data3)
print("PUT request data:", json_data3)
conn.request("PUT", url3, body=json_data3, headers=headers)
response3 = conn.getresponse()
print("Response:", response3.reason)
print("Status:", response3.status)
third_response = json.loads(response3.read().decode())["message"]
print("Third Response:", third_response)


# fourth request of delete
endpointDelete = "/test_delete_method"
delete_query_params = urllib.parse.urlencode({"id": third_response})
url4 = f"{endpointDelete}?{delete_query_params}"
conn.request("DELETE", url4, headers=headers)
response4 = conn.getresponse()
print("Response:", response4.reason)
print("Status:", response4.status)
conn.close()
